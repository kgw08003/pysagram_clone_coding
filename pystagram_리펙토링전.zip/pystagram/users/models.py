from django.contrib.auth.models import AbstractUser
from django.db import models

# Create your models here.
class User(AbstractUser):
    profile_image = models.ImageField("프로필 이미지", upload_to="users/profile", blank=True)
    short_description = models.TextField("소개글", blank=True)

# AbstractUser 모델의 필드
#     username (사용자명, 로그인 할 때의 아이디)
#     password (비밀번호)
#     first_name (이름)
#     last_name (성)
#     emil (이메일)
#     is_staff (관리자 여부)
#     is_active (활성화 여부)
#     date_joined (가입일시)
#     last_login (마지막 로그인 일시)